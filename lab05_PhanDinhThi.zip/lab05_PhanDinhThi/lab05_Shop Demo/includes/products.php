<?php
// includes/products.php

$products = [
    1 => ['name' => 'Áo thun', 'price' => 120000],
    2 => ['name' => 'Quần jean', 'price' => 350000],
    3 => ['name' => 'Giày sneaker', 'price' => 650000],
    4 => ['name' => 'Balo', 'price' => 280000],
];
